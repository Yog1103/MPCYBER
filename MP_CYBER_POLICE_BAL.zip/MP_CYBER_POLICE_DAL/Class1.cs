﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MP_CYBER_POLICE_DAL
{
    public class Class1
    {
    }
}
